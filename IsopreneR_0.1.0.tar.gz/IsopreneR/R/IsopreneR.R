#' IsopreneR package
#'
#' Contains a function to extract local peak summits
#' and valleys from a time-resolved breath profile
#'
#' @docType package
#'
#' @author Andrea Romano \email{andrea.romano910@gmail.com}
#'
#' @name IsopreneR
NULL
