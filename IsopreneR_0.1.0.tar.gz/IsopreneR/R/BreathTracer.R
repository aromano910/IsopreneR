
breath.tracer<-function(x,window=5,...) {

  highs<-NULL
  lows<-NULL

  for (n in seq(length(x))) {

    if ((n-window)<0) start<-n else start<-n-window
    if ((n+window)>length(x)) end<-n else end<-n+window

    high<-x[n]-mean(x[start:end])
    highs<-c(highs,high)

  }

  verifier<-sapply(log(highs),is.na)

  clumps<-which(verifier==F)
  clumps.low<-which(verifier==T)

  clump.no<-1
  clump.nos<-NULL

  for(n in seq(length(clumps))[-1]) {

    if(clumps[n]-clumps[n-1]==1) clump.no<-clump.no else clump.no<-clump.no+1
    clump.nos<-c(clump.nos,clump.no)

  }

  clump.no.low<-1
  clump.nos.low<-NULL

  for(n in seq(length(clumps.low))[-1]) {

    if(clumps.low[n]-clumps.low[n-1]==1) clump.no.low<-clump.no.low else clump.no.low<-clump.no.low+1
    clump.nos.low<-c(clump.nos.low,clump.no.low)

  }

  clump.nos<-c(1,clump.nos)

  scanner<-levels(as.factor(clump.nos))
  highs.clumps<-x[clumps]
  spikes.y<-NULL

  for(n in scanner) {

    grabber<-grep(paste("x",n,"x",sep=""),paste("x",clump.nos,"x",sep=""))
    spike.y<-max(highs.clumps[grabber])
    spikes.y<-c(spikes.y,spike.y)

  }

  spikes.x<-NULL

  for(n in spikes.y) {

    spike.x<-which(x==n)[1]
    spikes.x<-c(spikes.x,spike.x)

  }

  clump.nos.low<-c(1,clump.nos.low)

  scanner.low<-levels(as.factor(clump.nos.low))
  highs.clumps.low<-x[clumps.low]
  spikes.y.low<-NULL

  for(n in scanner.low) {

    grabber<-grep(paste("x",n,"x",sep=""),paste("x",clump.nos.low,"x",sep=""))
    spike.y.low<-min(highs.clumps.low[grabber])
    spikes.y.low<-c(spikes.y.low,spike.y.low)

  }

  spikes.x.low<-NULL

  for(n in spikes.y.low) {

    spike.x.low<-which(x==n)[1]
    spikes.x.low<-c(spikes.x.low,spike.x.low)

  }

  invisible(list(spikes.x,spikes.x.low))

}
